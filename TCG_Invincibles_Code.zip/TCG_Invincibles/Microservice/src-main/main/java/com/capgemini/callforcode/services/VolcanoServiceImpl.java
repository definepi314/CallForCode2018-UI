package com.capgemini.callforcode.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigurationPackage;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.callforcode.dtos.ChecklistDTO;
import com.capgemini.callforcode.dtos.LoginDTO;
import com.capgemini.callforcode.dtos.SiteDTO;
import com.capgemini.callforcode.dtos.VolcanoDTO;
import com.capgemini.callforcode.dtos.ZoneDTO;
import com.capgemini.callforcode.exception.CallForCodeException;
import com.capgemini.callforcode.repositories.CheckListRepository;
import com.capgemini.callforcode.repositories.DisasterMasterRepository;
import com.capgemini.callforcode.repositories.LoginMasterRepository;
import com.capgemini.callforcode.repositories.PersonTutorialDetailsRepository;
import com.capgemini.callforcode.repositories.TutorialMasterRepository;
import com.capgemini.callforcode.repositories.VolcanoDetailsRepository;
import com.capgemini.callforcode.repositories.VolcanoMasterRepository;
import com.capgemini.callforcode.reusable.transaction.entity.AddressDetailsEntity;
import com.capgemini.callforcode.reusable.transaction.entity.CheckListEntity;
import com.capgemini.callforcode.reusable.transaction.entity.DisasterMasterEntity;
import com.capgemini.callforcode.reusable.transaction.entity.LoginMasterEntity;
import com.capgemini.callforcode.reusable.transaction.entity.TutorialMasterEntity;
import com.capgemini.callforcode.reusable.transaction.entity.VolcanoDetailsEntity;
import com.capgemini.callforcode.reusable.transaction.entity.VolcanoMasterEntity;

@Service
public class VolcanoServiceImpl implements VolcanoService {

	@Autowired
	VolcanoMasterRepository volcanoMasterRepository;

	@Autowired
	VolcanoDetailsRepository volcanoDetailsRepository;
	
	@Autowired
	DisasterMasterRepository disasterMasterRepository;
	
	@Autowired
	TutorialMasterRepository tutorialMasterRepository;
	
	@Autowired
	CheckListRepository checkListRepository;
	
	@Autowired
	LoginMasterRepository loginMasterRepository;
	
	@Autowired
	PersonTutorialDetailsRepository personTutorialDetailsRepository;

	@Override
	public List<VolcanoDTO> getVolcanoCentre() throws CallForCodeException {
		List<VolcanoDTO> volcanoDTOs = new ArrayList<>();
		VolcanoDTO volcanoDTO = null;
		List<VolcanoMasterEntity> volcanoMasterEntities = volcanoMasterRepository.findAll();
		for (VolcanoMasterEntity volcanoMasterEntity : volcanoMasterEntities) {
			volcanoDTO = new VolcanoDTO();
			volcanoDTO.setLatitude(volcanoMasterEntity.getVolcanoDetailsEntity().getLatitude());
			volcanoDTO.setLongitude(volcanoMasterEntity.getVolcanoDetailsEntity().getLongitude());
			volcanoDTO.setVolcanoName(volcanoMasterEntity.getVolcanoName());
			volcanoDTO.setVolcanoId(volcanoMasterEntity.getVolcanoMasterId());
			volcanoDTO.setBlueZone(volcanoMasterEntity.getVolcanoDetailsEntity().getBlueZone());
			volcanoDTO.setYellowZone(volcanoMasterEntity.getVolcanoDetailsEntity().getYellowZone());
			volcanoDTO.setRedZone(volcanoMasterEntity.getVolcanoDetailsEntity().getRedZone());
			volcanoDTOs.add(volcanoDTO);
		}
		return volcanoDTOs;
	}

	@Override
	public List<VolcanoDTO> addZone(ZoneDTO zoneDto) throws CallForCodeException {
		VolcanoMasterEntity volcanoMasterEntity = null;
		if(zoneDto.getVolcanoId() == 0){
			System.out.println("hi i am in");
			VolcanoMasterEntity volcanoMasterEntity1 = new VolcanoMasterEntity();
			volcanoMasterEntity1.setVolcanoName(zoneDto.getVolcanoName());
			volcanoMasterEntity1.setCreatedBy("Admin");
			volcanoMasterEntity1.setCreatedDate(new Date());
			volcanoMasterEntity = volcanoMasterRepository.save(volcanoMasterEntity1);
			VolcanoDetailsEntity volcanoDetailsEntity = new VolcanoDetailsEntity();
			volcanoDetailsEntity.setCreatedBy("Admin");
			volcanoDetailsEntity.setCreatedDate(new Date());
			volcanoDetailsEntity.setLatitude(zoneDto.getLatitude());
			volcanoDetailsEntity.setLongitude(zoneDto.getLongitude());
			volcanoDetailsEntity.setVolcanoMasterEntity(volcanoMasterEntity);
			volcanoDetailsEntity = volcanoDetailsRepository.save(volcanoDetailsEntity);
			volcanoMasterEntity.setVolcanoDetailsEntity(volcanoDetailsEntity);
			volcanoMasterRepository.save(volcanoMasterEntity);
		}else{
			volcanoMasterEntity = volcanoMasterRepository.findOne(zoneDto.getVolcanoId());
		}
		if (volcanoMasterEntity != null) {
			VolcanoDetailsEntity volcanoDetailsEntity = volcanoMasterEntity.getVolcanoDetailsEntity();
			switch (zoneDto.getZoneId()) {
			case 1:
				volcanoDetailsEntity.setRedZone(zoneDto.getZone());
				volcanoDetailsRepository.save(volcanoDetailsEntity);
				return getVolcanoCentre();

			case 2:
				volcanoDetailsEntity.setYellowZone(zoneDto.getZone());
				volcanoDetailsRepository.save(volcanoDetailsEntity);
				return getVolcanoCentre();

			case 3:
				volcanoDetailsEntity.setBlueZone(zoneDto.getZone());
				volcanoDetailsRepository.save(volcanoDetailsEntity);
				return getVolcanoCentre();

			default:
				return getVolcanoCentre();

			}

		} else {
			throw new CallForCodeException("VOLCANO SITE NOT REGISTERED");
		}
	}

	@Override
	public Boolean addDisasterChecklist(ChecklistDTO checklistDto) throws CallForCodeException {
		System.out.println(checklistDto.getTrainingType());
		DisasterMasterEntity disasterMasterEntity = disasterMasterRepository.findOne(checklistDto.getDisasterId());
		if(disasterMasterEntity != null){
			if("tutorial".equalsIgnoreCase(checklistDto.getTrainingType())){
				TutorialMasterEntity tutorialMasterEntity = null;
				for(String training : checklistDto.getChecklists()){
					tutorialMasterEntity = new TutorialMasterEntity();
					tutorialMasterEntity.setVideoLink(training);
					tutorialMasterEntity.setDisasterMasterEntity(disasterMasterEntity);
					tutorialMasterRepository.save(tutorialMasterEntity);
				}
			}else if("checklist".equalsIgnoreCase(checklistDto.getTrainingType())){
				CheckListEntity checkListEntity = null;
				for(String training : checklistDto.getChecklists()){
					checkListEntity = new CheckListEntity();
					checkListEntity.setCheckListName(training);
					checkListEntity.setDisasterMasterEntity(disasterMasterEntity);
					checkListRepository.save(checkListEntity);
				}
			}else{
				return false;
			}
			return true;
		}else{
			throw new CallForCodeException();
		}
	}

	@Override
	public List<String> getCheckListByUser(LoginDTO loginDTO) throws CallForCodeException {
		LoginMasterEntity loginMasterEntity = loginMasterRepository.findByUserNameAndPassword(loginDTO.getUsername(), loginDTO.getPassword());
		if(loginMasterEntity != null){
			return checkListRepository.getChecklistByUser(loginMasterEntity.getPersonMasterEntity().getPersonId());
		}else{
			throw new CallForCodeException("USER NOT REGISTERED");
		}
	}

	@Override
	public List<String> getTutorial(LoginDTO loginDTO) throws CallForCodeException {
		LoginMasterEntity loginMasterEntity = loginMasterRepository.findByUserNameAndPassword(loginDTO.getUsername(), loginDTO.getPassword());
		if(loginMasterEntity != null){
			return personTutorialDetailsRepository.getTutorialByUser(loginMasterEntity.getPersonMasterEntity().getPersonId());
		}else{
			throw new CallForCodeException("USER NOT REGISTERED");
		}
	}

	

}
