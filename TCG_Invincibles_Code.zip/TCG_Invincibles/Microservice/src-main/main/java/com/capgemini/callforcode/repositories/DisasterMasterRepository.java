package com.capgemini.callforcode.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.callforcode.reusable.transaction.entity.DisasterMasterEntity;

public interface DisasterMasterRepository extends JpaRepository<DisasterMasterEntity, Long> {

}
