package com.capgemini.callforcode.services;

public interface IBMWatsonService {

	void languageTranslator();

	public String chatbotResponse(String inputText);

}
