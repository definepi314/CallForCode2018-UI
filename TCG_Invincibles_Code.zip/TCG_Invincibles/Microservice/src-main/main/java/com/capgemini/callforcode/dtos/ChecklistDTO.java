package com.capgemini.callforcode.dtos;

import java.util.List;

public class ChecklistDTO {

	private long disasterId;
	private String trainingType;
	private List<String> checklists;

	public long getDisasterId() {
		return disasterId;
	}

	public void setDisasterId(long disasterId) {
		this.disasterId = disasterId;
	}

	public List<String> getChecklists() {
		return checklists;
	}

	public void setChecklists(List<String> checklists) {
		this.checklists = checklists;
	}

	public String getTrainingType() {
		return trainingType;
	}

	public void setTrainingType(String trainingType) {
		this.trainingType = trainingType;
	}

}
