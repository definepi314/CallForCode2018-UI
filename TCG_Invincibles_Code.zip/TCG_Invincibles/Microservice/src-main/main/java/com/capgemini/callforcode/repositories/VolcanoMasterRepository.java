package com.capgemini.callforcode.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.callforcode.reusable.transaction.entity.VolcanoMasterEntity;

public interface VolcanoMasterRepository extends JpaRepository<VolcanoMasterEntity, Long> {

	@Query("select v from VolcanoMasterEntity v where v.volcanoMasterId in (select d.volcanoMasterEntity.volcanoMasterId from VolcanoCityDetails d where d.cityMasterEntity.cityId = ?1)")
	List<VolcanoMasterEntity> getVolcanoMasterByCity(long cityId);

}
