package com.capgemini.callforcode.services;

import java.util.List;

import com.capgemini.callforcode.dtos.ChecklistDTO;
import com.capgemini.callforcode.dtos.LoginDTO;
import com.capgemini.callforcode.dtos.VolcanoDTO;
import com.capgemini.callforcode.dtos.ZoneDTO;
import com.capgemini.callforcode.exception.CallForCodeException;

public interface VolcanoService {

	public List<VolcanoDTO> getVolcanoCentre() throws CallForCodeException;

	public List<VolcanoDTO> addZone(ZoneDTO zoneDto) throws CallForCodeException;

	public Boolean addDisasterChecklist(ChecklistDTO checklistDto) throws CallForCodeException;

	public List<String> getCheckListByUser(LoginDTO loginDTO) throws CallForCodeException;

	public List<String> getTutorial(LoginDTO loginDTO) throws CallForCodeException;

}
