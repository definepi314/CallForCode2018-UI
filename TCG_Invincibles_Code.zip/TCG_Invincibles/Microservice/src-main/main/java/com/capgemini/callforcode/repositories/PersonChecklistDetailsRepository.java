package com.capgemini.callforcode.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.callforcode.reusable.transaction.entity.PersonChecklistDetailsEntity;

public interface PersonChecklistDetailsRepository extends JpaRepository<PersonChecklistDetailsEntity, Long> {

}
