package com.capgemini.callforcode.dtos;

public class SiteDTO {

	private String volcanoName;
	private String latitude;
	private String longitude;

	public String getVolcanoName() {
		return volcanoName;
	}

	public void setVolcanoName(String volcanoName) {
		this.volcanoName = volcanoName;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

}
