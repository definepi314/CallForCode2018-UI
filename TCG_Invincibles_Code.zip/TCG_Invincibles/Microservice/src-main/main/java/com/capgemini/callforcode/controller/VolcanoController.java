package com.capgemini.callforcode.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.callforcode.dtos.ChecklistDTO;
import com.capgemini.callforcode.dtos.LoginDTO;
import com.capgemini.callforcode.dtos.ResponseDto;
import com.capgemini.callforcode.dtos.SiteDTO;
import com.capgemini.callforcode.dtos.VolcanoDTO;
import com.capgemini.callforcode.dtos.ZoneDTO;
import com.capgemini.callforcode.exception.CallForCodeException;
import com.capgemini.callforcode.services.FirebaseService;
import com.capgemini.callforcode.services.VolcanoService;

@RestController
@RequestMapping("/volcano")
public class VolcanoController {
	
	@Autowired
	VolcanoService volcanoService;
	
	@Autowired
	FirebaseService firebaseService;
	
	@RequestMapping("/getVolcanoCentre")
	public ResponseDto getVolcanoCentre(){
		ResponseDto responseDto = new ResponseDto();
		List<VolcanoDTO> volcanoDtos = null;
		try {
			volcanoDtos = volcanoService.getVolcanoCentre();
			responseDto.setResponse(volcanoDtos);
		} catch (CallForCodeException e) {
			responseDto.setException(e.getMessage());
		}
		return responseDto;
	}
	
	@RequestMapping("addZone")
	public ResponseDto addZone(@RequestBody ZoneDTO zoneDto){
		ResponseDto responseDto = new ResponseDto();
		List<VolcanoDTO> volcanoDtos = null;
		try {
			volcanoDtos = volcanoService.addZone(zoneDto);
			responseDto.setResponse(volcanoDtos);
		} catch (CallForCodeException e) {
			responseDto.setException(e.getMessage());
		}
		return responseDto;
	}
	
	@RequestMapping("addCheckList")
	public ResponseDto addDisasterCheckList(@RequestBody ChecklistDTO checklistDto){
		ResponseDto responseDto = new ResponseDto();
		Boolean addSuccess = null;
		try {
			addSuccess = volcanoService.addDisasterChecklist(checklistDto);
			responseDto.setResponse(addSuccess);
		} catch (CallForCodeException e) {
			responseDto.setException(e.getMessage());
		}
		return responseDto;
	}
	
	@RequestMapping("getCheckList")
	public ResponseDto getCheckListByUser(@RequestBody LoginDTO loginDTO){
		ResponseDto responseDto = new ResponseDto();
		List<String> checklistDTOs = null;
		try {
			checklistDTOs = volcanoService.getCheckListByUser(loginDTO);
			responseDto.setResponse(checklistDTOs);
		} catch (CallForCodeException e) {
			responseDto.setException(e.getMessage());
		}
		return responseDto;
	}
	
	@RequestMapping("getTutorial")
	public ResponseDto getTutorialByUser(@RequestBody LoginDTO loginDTO){
		ResponseDto responseDto = new ResponseDto();
		List<String> checklistDTOs = null;
		try {
			checklistDTOs = volcanoService.getTutorial(loginDTO);
			responseDto.setResponse(checklistDTOs);
		} catch (CallForCodeException e) {
			responseDto.setException(e.getMessage());
		}
		return responseDto;
	}

}
