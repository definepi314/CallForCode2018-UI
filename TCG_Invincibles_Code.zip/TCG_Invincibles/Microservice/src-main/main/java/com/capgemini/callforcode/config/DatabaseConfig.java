package com.capgemini.callforcode.config;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.capgemini.callforcode.services.Messages;

@Configuration
public class DatabaseConfig {
	private static final int MAX_ACTIVE = 2;
	private static final int MAX_AGE = 1000;
	private static final int IDLE_TIME = 60000;

	@Bean
	public DataSource postgresDataSource() {
		javax.sql.DataSource ds = DataSourceBuilder.create().username(Messages.getString("user"))
				.password(Messages.getString("password")).url(Messages.getString("url"))
				.driverClassName(Messages.getString("driver")).build();
		if (ds instanceof org.apache.tomcat.jdbc.pool.DataSource) {
			((org.apache.tomcat.jdbc.pool.DataSource) ds).setInitialSize(1);
			((org.apache.tomcat.jdbc.pool.DataSource) ds).setMaxActive(MAX_ACTIVE);
			((org.apache.tomcat.jdbc.pool.DataSource) ds).setMaxAge(MAX_AGE);
			((org.apache.tomcat.jdbc.pool.DataSource) ds).setMinIdle(0);
			((org.apache.tomcat.jdbc.pool.DataSource) ds).setMinEvictableIdleTimeMillis(IDLE_TIME);
		}
		return ds;
	}

}
