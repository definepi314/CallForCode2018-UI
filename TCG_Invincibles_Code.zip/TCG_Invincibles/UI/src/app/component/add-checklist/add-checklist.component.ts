import { DisasterTrainingService } from './../../service/disaster-training.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

export class disaster {
  id: number;
  name: string;
}

@Component({
  selector: 'app-add-checklist',
  templateUrl: './add-checklist.component.html',
  styleUrls: ['./add-checklist.component.css']
})

export class AddChecklistComponent implements OnInit {
  disasterId: any;
  checkListTemp: any;
  checkLists: disaster[];
  serviceDatas: any;
  serviceData = [];
  emptyService: any;
  appDisasterForm: FormGroup;
  checkTypes = [
    { value: 'checklist', viewValue: 'CheckList' },
    { value: 'tutorial', viewValue: 'Tutorial' },
  ]
  constructor(public disasterTrainService: DisasterTrainingService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.serviceData = []
    this.disasterTrainService.lookupDisaster().subscribe((res: disaster[]) => {
      console.log(res);
      this.checkLists = res;
    })
    this.appDisasterForm = this.formBuilder.group({
      disasterType: '',
      tutorialType: ''
    })
  }
  changeList(event) {
    console.log(event.value.id);
    this.disasterId=event.value.id;
  }
  serviceOutput(event) {
    console.log(event)
    this.serviceDatas = event;
    console.log(event);
    this.serviceData.push(event.comment);
    console.log(this.serviceData);
  }


  addMoreServices() {
    console.log(this.sample.length);
    this.emptyService = {
      "comments": '',
    }
    this.sample.push(this.emptyService.comments);
    console.log(this.sample)

    // if (this.serviceDatas.seviceName !== undefined && this.serviceDatas.servicePlan !== undefined && this.serviceDatas.serviceType !== undefined) {
    //   //console.log('Hi');
    //   this.sample.push(this.emptyService);
    // }
    if (this.sample.length > 1) {
      document.getElementById('deleteServiceButton').style.opacity = '1'
      document.getElementById('deleteServiceButton').style.cursor = 'pointer';
    }
  }
  DeleteServices() {
    //this.sample.pop();
    if (this.sample.length > 1) {
      this.sample.pop();
    }
    if (this.sample.length === 1) {
      document.getElementById('deleteServiceButton').style.opacity = '0.6'
      document.getElementById('deleteServiceButton').style.cursor = 'not-allowed';
    }
  }
  sample: Array<number> = [1];

  submitDisaster(event) {
    //console.log(event);
    let disasterBody = {
      "disasterId": this.disasterId,
      "trainingType": event.tutorialType,
      "checklists": this.serviceData
    }
    console.log(disasterBody);
    this.disasterTrainService.addCheckList(disasterBody).subscribe(res=>{
      console.log(res);
      if(res['response']==="true")
      {
        //this.toastr.success('', 'Successfully Checklist Saved');
      }
    },
    err => {
      console.log(err);
      //this.toastr.error('', 'Checklist does not Saved');
    })
  }
  // reset() {
  //   this.appDisasterForm.reset();
  //   this.serviceData=[];
  // }
}
