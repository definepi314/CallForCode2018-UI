import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tutorial-videos',
  templateUrl: './tutorial-videos.component.html',
  styleUrls: ['./tutorial-videos.component.css']
})
export class TutorialVideosComponent implements OnInit {
  srcPath:String;
  videoFlag:boolean=false;
  videos=[{
    name:'video1',
    path:'https://youtu.be/Z-w_z9yobpE'
  },
  {
    name:'video2',
    path:'https://youtu.be/WgktM2luLok'
  },
  ]
  constructor() { }

  ngOnInit() {
  }
  videoLink(video)
  {
    this.videoFlag=true
    this.srcPath=video.path;
  }
}
