import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disaster-trainig',
  templateUrl: './disaster-trainig.component.html',
  styleUrls: ['./disaster-trainig.component.css']
})
export class DisasterTrainigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
