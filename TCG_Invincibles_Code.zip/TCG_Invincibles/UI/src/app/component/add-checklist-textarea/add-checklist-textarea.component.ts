import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-add-checklist-textarea',
  templateUrl: './add-checklist-textarea.component.html',
  styleUrls: ['./add-checklist-textarea.component.css']
})
export class AddChecklistTextareaComponent implements OnInit {
  comment;
  emptyService: any;
  serviceData = [];
  serviceDatas: any;
  @Output() output = new EventEmitter<Object>();
  constructor() { }

  ngOnInit() {
    this.serviceData = [];
  }
  emitData() {
    //console.log("Blur")
    this.output.emit({
      "comment": this.comment,
    });
  }
  serviceOutput(event) {
    this.serviceDatas = event;
    console.log(event);
    this.serviceData.push(event.comment);
    console.log(this.serviceData);
  }
  addMoreServices() {
    console.log(this.sample.length);
    this.emptyService = {
      "comments": '',
      "subchecklist": this.serviceDatas,
    }
    this.sample.push(this.emptyService.comments);
    console.log(this.sample)

    // if (this.serviceDatas.seviceName !== undefined && this.serviceDatas.servicePlan !== undefined && this.serviceDatas.serviceType !== undefined) {
    //   //console.log('Hi');
    //   this.sample.push(this.emptyService);
    // }
    if (this.sample.length > 1) {
      document.getElementById('deleteServiceButton1').style.opacity = '1'
      document.getElementById('deleteServiceButton1').style.cursor = 'pointer';
    }
  }
  DeleteServices() {
    //this.sample.pop();
    if (this.sample.length > 1) {
      this.sample.pop();
    }
    if (this.sample.length === 1) {
      document.getElementById('deleteServiceButton1').style.opacity = '0.6'
      document.getElementById('deleteServiceButton1').style.cursor = 'not-allowed';
    }
  }
  sample: Array<number> = [1];

}
