import { Component, OnInit } from '@angular/core';
import { Message } from '../../model';

@Component({
  selector: 'app-render-component',
  templateUrl: './render-component.component.html',
  styleUrls: ['./render-component.component.css']
})
export class RenderComponentComponent implements OnInit {

  public message: Message;
  public messages: Message[];


  constructor() {
  }

  ngOnInit() {
    this.message = new Message('', 'assets/Images/user.png');  // user
    this.messages = [
      new Message('Welcome to chatbot universe', 'assets/Images/bot.png', new Date())  // bot
    ];
  }
}
