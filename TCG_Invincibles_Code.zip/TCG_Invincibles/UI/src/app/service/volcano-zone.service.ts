import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class VolcanoZoneService {
  //posturl = 'http://3.209.34.69:8081/volcano/addZone';
 // private posturl = "https://callforcode-ms-prod.run.aws-usw02-pr.ice.predix.io/volcano/addZone";
   private posturl = "https://disaster-service.mybluemix.net/volcano/addZone";

  //getVolcanoDetails = 'http://3.209.34.69:8081/volcano/getVolcanoCentrevolcano';
 // private getVolcanoDetails = "https://callforcode-ms-prod.run.aws-usw02-pr.ice.predix.io/volcano/addZone";
 private getVolcanoDetails = "https://disaster-service.mybluemix.net/volcano/addZone";

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private http: HttpClient) { }

  addVolcano(body) {
    return this.http.post(this.posturl, body, this.httpOptions);
  }

}
